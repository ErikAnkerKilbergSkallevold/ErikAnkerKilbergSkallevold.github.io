function setup() {
  // put setup code here
  createCanvas(400, 400);

}

function draw() {
  // put drawing code here
  background(220);
  circle(200, 200, 147);

  /*

  Jeg får ikke lenket JS koden, sammen med P5. 

  */

}
